---
title: "mg_dns_encode_name()"
decl_name: "mg_dns_encode_name"
symbol_kind: "func"
signature: |
  int mg_dns_encode_name(struct mbuf *io, const char *name, size_t len);
---

Encodes a DNS name. 

