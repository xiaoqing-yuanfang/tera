# Nexus Python API手册

为满足Python用户的需求，方便编写web监控等程序，因此使用ctypes库来实现了Python版本的接口。  
考虑到Python版本实际上是C++版本的封装，大部分功能也与C++版本相同，因此暂时烦请参考[C++手册](cxx_api_cn.md)，我们会尽快完善这个手册。  
Python版本的接口是为Python 2.7设计的，我们也在努力使其兼容Python 3.x  
祝编程愉快！  

