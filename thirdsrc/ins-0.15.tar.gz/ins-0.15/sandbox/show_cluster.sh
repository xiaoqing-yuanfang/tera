#!/bin/bash
../output/bin/ins_cli --ins_cmd=show --flagfile=ins.flag
