#!/bin/bash
../output/bin/ins_cli --ins_cmd=whoami --flagfile=ins.flag
