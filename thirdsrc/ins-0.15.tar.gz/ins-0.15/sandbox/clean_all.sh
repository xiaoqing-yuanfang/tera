#!/bin/bash

./stop_all.sh

sleep 1
rm -rf *.log ins.flag binlog/ data/
