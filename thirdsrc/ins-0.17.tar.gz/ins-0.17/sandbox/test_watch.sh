#!/bin/bash
../output/bin/ins_cli --ins_cmd=watch --flagfile=nexus.flag --ins_key=$1

