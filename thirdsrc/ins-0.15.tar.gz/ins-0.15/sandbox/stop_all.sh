#!/bin/bash
killall -9 ins

