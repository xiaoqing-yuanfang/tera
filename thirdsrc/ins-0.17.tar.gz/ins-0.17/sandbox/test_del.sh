#!/bin/bash
../output/bin/ins_cli --ins_cmd=delete --flagfile=nexus.flag --ins_key=$1

