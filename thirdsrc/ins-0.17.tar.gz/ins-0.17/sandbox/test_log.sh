#!/bin/bash
../output/bin/ins_cli --ins_cmd=login --flagfile=nexus.flag --ins_key=$1 --ins_value=$2

