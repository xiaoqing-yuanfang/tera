#!/bin/bash
../output/bin/ins_cli --ins_cmd=login --flagfile=ins.flag --ins_key=$1 --ins_value=$2

