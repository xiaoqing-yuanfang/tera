/*
 * Copyright (c) 2014-2017 Cesanta Software Limited
 * All rights reserved
 */

#pragma once

void led_setup(int io);
void led_on(int io);
void led_off(int io);
void led_toggle(int io);
