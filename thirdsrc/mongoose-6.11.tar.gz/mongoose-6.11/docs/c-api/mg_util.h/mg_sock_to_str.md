---
title: "mg_sock_to_str()"
decl_name: "mg_sock_to_str"
symbol_kind: "func"
signature: |
  void mg_sock_to_str(sock_t sock, char *buf, size_t len, int flags);
---

Legacy interface. 

