#!/bin/bash
../output/bin/ins_cli --ins_cmd=lock --flagfile=nexus.flag --ins_key=$1

