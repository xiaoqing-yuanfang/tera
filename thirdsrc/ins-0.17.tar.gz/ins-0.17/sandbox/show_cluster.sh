#!/bin/bash
../output/bin/ins_cli --ins_cmd=show --flagfile=nexus.flag
